
public class Database {
    // and so we embark on doing this homework
    //first we create the database
    public static final String DATABASE_URL="jdbc:derby://localhost:1527/adressbook";
    public static final String USERNAME="uta";
    public static final String PASSWORD="12345";
    
    //simple enough now we have completed the   database class
    //now we create address class
}
