
public class Bicycle extends Vehicle { //creating bicycle that extends to vehicle
    @Override
    public double GetCarbonFootPrint() {
       return 0; //returns 0 because bikes dont harm the earth 
    }
}
