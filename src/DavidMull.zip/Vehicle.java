
abstract class Vehicle {
    //creating abstract method for GetCarbonFootprint
    public abstract double GetCarbonFootPrint();
}
